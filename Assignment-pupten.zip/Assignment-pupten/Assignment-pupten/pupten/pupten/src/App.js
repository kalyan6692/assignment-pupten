import "./App.css";
import Booking from "./Components/Booking/Booking";
import Footer from "./Components/Footer/Footer";
import Header from "./Components/Header/Header";

function App() {
  return (
    <div className="App">
      <Header />
      <Booking />
      <Footer />
    </div>
  );
}

export default App;
