import React, { useState, useEffect } from "react";
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import { MapContainer, Marker, TileLayer } from "react-leaflet";
import PhoneIcon from "@material-ui/icons/Phone";
import MailIcon from "@material-ui/icons/Mail";
import QueryBuilderIcon from "@material-ui/icons/QueryBuilder";
import HomeIcon from "@material-ui/icons/Home";
import hospitalData from "../../data.json";
import "./Booking.css";

const date = new Date();
date.setDate(date.getDate()+2);
function Booking() {
  const [location, setLocation] = useState("");
  const [speciality, setSpeciality] = useState("");
  const [filteredData, setFilteredData] = useState(null);
  const [activePark, setActivePark] = React.useState(null);
  const [time, setTime] = useState(false);
  useEffect(() => {
    let newArray = hospitalData.hospitalList.filter(function (el) {
      return (
        (el.address.toLowerCase().includes(location.toLowerCase()) ||
          el.country.toLowerCase().includes(location.toLowerCase()) ||
          el.city.toLowerCase().includes(location.toLowerCase())) &&
        el.speciality.toLowerCase() === speciality.toLowerCase()
      );
    });
    setFilteredData(newArray);
  }, [location, speciality]);
  const handleTime = () => {
    setTime(true);
  };
  return (
    <React.Fragment>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <h3 for="location">Enter Country, City or Postal Code</h3>
          <br />
          <TextField
            id="location"
            variant="standard"
            name="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </Grid>
        <Grid item xs={6}>
          <h3 for="doctorOption">Doctor's Speciality</h3>
          <br />
          <Select
            labelId="demo-simple-select-label"
            id="doctorOption"
            name="speciality"
            value={speciality}
            onChange={(e) => setSpeciality(e.target.value)}
          >
            <MenuItem value="Cardiology">Cardiology</MenuItem>
            <MenuItem value="Dermatology">Dermatology</MenuItem>
            <MenuItem value="Gynaecology">Gynaecology</MenuItem>
            <MenuItem value="Radiology">Radiology</MenuItem>
            <MenuItem value="Pediatrics">Pediatrics</MenuItem>
          </Select>
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          {filteredData && filteredData.length > 0 && (
            <p>{filteredData.length} Results near your location</p>
          )}
          <MapContainer center={[23.18283, 77.4344799]} zoom={10}>
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            {filteredData &&
              filteredData.map((data) => (
                <Marker
                  key={data.id}
                  position={[
                    data.geometry.coordinates[0],
                    data.geometry.coordinates[1],
                  ]}
                  eventHandlers={{
                    click: (e) => {
                      setActivePark(data);
                    },
                  }}
                ></Marker>
              ))}
          </MapContainer>
        </Grid>
        <Grid item xs={6}>
          <Grid container>
            <Grid item xs={6}>
              {activePark && (
                <div className="details">
                  <h2>
                    <HomeIcon
                      style={{
                        backgroundColor: "#588b8b",
                        color: "#ffffff",
                        borderRadius: "1rem",
                      }}
                    />
                    &nbsp;&nbsp;
                    {activePark.name}
                  </h2>
                  <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
                    {activePark.address}
                  </p>
                  <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <PhoneIcon
                      fontSize="small"
                      style={{
                        color: "#588b8b",
                      }}
                    />
                    &nbsp;&nbsp;
                    {activePark.mobileNo}
                  </p>
                  <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <MailIcon
                      fontSize="small"
                      style={{
                        color: "#588b8b",
                      }}
                    />
                    &nbsp;&nbsp;
                    {activePark.emailId}
                  </p>
                  <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    {activePark.doctorName}&nbsp;&nbsp; (
                    {activePark.doctorDesgination})
                  </p>
                  <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    {activePark.expYears} years Experience
                  </p>
                  <br />
                  <Grid container>
                    <Grid item>
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <button
                        variant="contained"
                        className="dateOfBooking"
                        onClick={handleTime}
                      >
                        Today
                      </button>
                    </Grid>
                    <Grid item>
                      <button
                        variant="contained"
                        className="dateOfBooking"
                        onClick={handleTime}
                      >
                        Tomorrow
                      </button>
                    </Grid>
                    <Grid item>
                      <button
                        variant="contained"
                        className="dateOfBooking"
                        onClick={handleTime}
                      >
                        {date.toString().substring(4, 15)}
                      </button>
                    </Grid>
                  </Grid>
                  <br />
                  {time && (
                    <Grid container>
                      <Grid item>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <button variant="contained" className="timeOfBooking">
                          11:00 AM
                        </button>
                      </Grid>
                      <Grid item>
                        <button variant="contained" className="timeOfBooking">
                          11:00 AM
                        </button>
                      </Grid>
                      <Grid item>
                        <button variant="contained" className="timeOfBooking">
                          11:00 AM
                        </button>
                      </Grid>
                    </Grid>
                  )}
                </div>
              )}
            </Grid>

            {time && (
              <Grid item xs={6}>
                <p className="hours">
                  <QueryBuilderIcon /> Hours
                </p>
                <p className="hours">Mon-Fri&nbsp;&nbsp; 08:00 AM - 10:00PM</p>
                <p className="hours">Sat&nbsp;&nbsp; 08:00AM - 10:00PM</p>
                <p className="hours">Sun&nbsp;&nbsp; Closed</p>
                <button className="book">Book</button>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}

export default Booking;
