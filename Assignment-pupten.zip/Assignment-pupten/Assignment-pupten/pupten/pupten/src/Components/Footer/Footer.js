import React from "react";
import logo from "../../Images/logo.svg";
import Grid from "@material-ui/core/Grid";
import FacebookIcon from "@material-ui/icons/Facebook";
import LinkedInIcon from "@material-ui/icons/LinkedIn";
import PhoneIcon from "@material-ui/icons/Phone";
import MailIcon from "@material-ui/icons/Mail";
import "./Footer.css";

function Footer() {
  return (
    <React.Fragment>
      <footer style={{ backgroundColor: "#588b8b" }}>
        <Grid container spacing={3}>
          <Grid item xs={3}>
            <img src={logo} alt="Pupten" />
            <br />
            <br />
            <FacebookIcon />
            <LinkedInIcon />
            <br />
            <br />
            <br />
            <MailIcon fontSize="small" />
            &nbsp;&nbsp; <span>founders@pupten.com</span>
            <br />
            <br />
            <PhoneIcon fontSize="small" />
            &nbsp;&nbsp; <span>+919693775328</span>
          </Grid>
          <Grid item xs={3}>
            <h4>PRODUCTS</h4>
            <h6>Veteniary Dashboard</h6>
            <h6>Caregiver Portal</h6>
            <h6>Find and book a vet</h6>
          </Grid>
          <Grid item xs={3}>
            <h4>PLATFORM</h4>
            <h6>Sign Up</h6>
            <h6>Book a Demo</h6>
            <h6>Blog</h6>
          </Grid>
          <Grid item xs={3}>
            <h4>INFORMATION</h4>
            <h6>Careers</h6>
            <h6>FAQS</h6>
            <h6>Privacy Policy</h6>
            <h6>Terms And Conditions</h6>
            <h6>Refund Policy</h6>
          </Grid>
        </Grid>
        <h4 className="copyright">
          Copyright @ 2021 Pupten. ALl Rights Reserved
        </h4>
      </footer>
    </React.Fragment>
  );
}

export default Footer;
